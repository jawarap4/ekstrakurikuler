// storage.js content
