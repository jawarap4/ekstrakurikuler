// firebase-config.js content
